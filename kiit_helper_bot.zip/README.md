# KIIT Helper Bot

Простий Telegram-бот для автоматичного оброблення повідомлень.

## Запуск

1. Створи `.env` файл з токеном:
```
TELEGRAM_BOT_TOKEN=your_token_here
```

2. Встанови залежності:
```
pip install -r requirements.txt
```

3. Запусти бота:
```
python main.py
```